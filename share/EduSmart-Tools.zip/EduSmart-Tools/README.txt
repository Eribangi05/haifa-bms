EduSmart Tools for Rwandan schools
===================================
by EduSmart Consult LTD, Kigali, Rwanda - www.edusmartconsult.com

WHAT IS IN THIS FOLDER
  START-HERE.html                         Open this first: what the tools do and how to start.
  EduSmart-Lesson-Plan-Generator.html     REB lesson plans, Primary 1 to Senior 6 (English, French, Kinyarwanda).
  EduSmart-School-Timetable.html          Clash-free school timetable, pre-primary to S6.

HOW TO USE
  1. Double-click an .html file. It opens in Chrome, Edge, Firefox or Safari. No installation, no internet needed.
  2. Follow the welcome screens (about two minutes).
  3. Print / Save PDF. In the print window choose "Save as PDF".
  4. Press "Save backup" now and then. Your work is kept inside the browser on that device only;
     use "Open backup" to move it to another computer.

SHARING
  Zip this folder and send it by email, WhatsApp, Google Drive or USB. The lesson plan file is about 16 MB.

IMPORTANT
  Plans are drafts built from REB 2026-2027 documents (Senior 1-6 are REB experimental versions).
  Review and edit every plan before use. These tools are not an official REB product.
